FlowState
=========

A small macOS menu bar app that graphs CPU, GPU, memory pressure, disk,
network, battery, and temperature. The menu bar shows whichever metric is
busiest right now; click it for a dropdown with two-minute graphs of
everything and the top processes.

  - Auto-switches the menu bar graph to the busiest metric, or pin one from
    the right-click menu.
  - Optional second metric in the menu bar, graph and/or value display,
    reorder or hide metrics.
  - Notifications for sustained high CPU, critical memory pressure, thermal
    throttling, low battery, and a charger too weak to keep up.
  - Quit, force quit, or reveal the apps using the most CPU and memory.
  - Built to stay out of the way: about 0.25% of one core when idle, no
    network access, nothing collected.


Requirements
------------

  - macOS 26 or later
  - Apple silicon

FlowState has only been run on the author's Mac. Sensors differ between
chips, so on other hardware a metric (most likely temperature or GPU) may
show as unavailable. Metrics a Mac doesn't have, such as battery on a
desktop, are hidden.


Install
-------

  1. Move FlowState.app to your Applications folder.
  2. Open it. macOS will say it can't be opened, because the app isn't
     notarized by Apple (see below).
  3. Go to System Settings > Privacy & Security, scroll down to the message
     about FlowState, and click Open Anyway. This is only needed once.

If you prefer the terminal, this does the same thing as step 3:

    xattr -dr com.apple.quarantine /Applications/FlowState.app

FlowState has no Dock icon or main window. Look for the graph in the menu
bar; Settings and Quit are in its right-click menu. Launch at login is in
Settings.


Why the warning?
----------------

Skipping that warning requires a paid Apple Developer account to sign and
notarize the app. FlowState is a free hobby project, so it's signed ad hoc
instead.


Updating
--------

There's no auto-update. Download the latest zip and replace the app; your
settings are kept.


Uninstall
---------

Quit FlowState, delete it from Applications, and optionally remove its
preferences:

    defaults delete com.zaftheory.flowstate


License
-------

Free to use. Copyright (c) 2026 zaftheory, all rights reserved; provided as
is, with no warranty. See LICENSE.txt in this folder.
